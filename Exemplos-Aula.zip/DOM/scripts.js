// Passo 1: Capturar o elemento

const elemento = document.getElementById("divComId")
elemento.innerHTML = "<h1>Adicionando um novo texto na DIV</h1>"

document.getElementById("divComId").innerHTML = "Novo texto!"

// Exemplo com parentesco

const parent = document.getElementById("parent")
console.log(parent)
const ultimoFilho = parent.lastElementChild;
ultimoFilho.innerHTML = "Estou alterando o texto do último filho"

// Adicionando um novo elemento HTML

const header = document.getElementsByTagName('header')[0];
// console.log(header)
const novoFilho = document.createElement("h2");
novoFilho.innerHTML = "Novo Filho";
header.appendChild(novoFilho);

novoFilho.style.color = "red"

